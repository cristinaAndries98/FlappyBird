Andries Cristina 334CC
IMPORTANT: Tema se afla in folderul TEMA1.

Am pornit implementarea temei de la Laboratorul 3. Prima oara am desenat pasarea, folosind ca figuri geometrice
patrat, romb si triunghi. Am facut o functie auxiliara numita createTriangle pentru a desena triunghiul si pentru
romb am folosit CreateSquare si dupa l-am rotit. In functie de rezolutie am dedus cum trebuie plasate figurile in asa fel incat sa se afle la jumatatea ecranului pasareasi sa fie elementele in continuare unul dupa celalalt, sa aiba macar un punct comun. 

Dupa aceea, am facut mediul in care zboara pasarea. Am facut cum se spunea in enunt: am creat doar o data dreptunghiuriul in Init si dupa in Update am desenat de fiecare data cand am avut nevoie. Am pus un if in functie de tx (daca e mai mic decat -lungimea dreptunghiului) ca sa verific daca iese din cadru dreptunghiul si trebuie sa il adaug la loc. Am pus o distanta egala intre dreptunghiuri, generandu-le dupa formula unei progresii. Fiecare pereche de dreptunghiuri are un TX al ei care permite ca dreptunghiul de sus si cel de jos sa se miste simultan. 

Apoi am trecut la animatia pasarii: aceasta are o gravitatie care o trage mereu in jos. Cand apas pe space, pasarea se
ridica putin cate putin. Daca cumva pasarea iese din parametrii rezolutiei, atunci inseamna clar ca jocul este pierdut 
si trebuie sa punem bool-ul de gameState pe false si sa iesim din jos - am facut functia GameEnd care pur si simplu
curata ecranul. Scorul este afisat la finalul jocului impreuna cu mesajul Game Over si se calculeaza in functie de 
timpul petrecut de pasare in joc. Pasarea are inclinatie realizata prin rotatii si translatii. 