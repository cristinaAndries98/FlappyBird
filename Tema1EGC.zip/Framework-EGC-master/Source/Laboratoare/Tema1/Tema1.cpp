#include "Tema1.h"
#include <vector>
#include <iostream>
#include <Core/Engine.h>
#include "Transform2D.h"
#include "Object2D.h"
using namespace std;

Tema1::Tema1()
{
}

Tema1::~Tema1()
{
}

void Tema1::Init()
{
	glm::ivec2 resolution = window->GetResolution();
	auto camera = GetSceneCamera();
	camera->SetOrthographic(0, (float)resolution.x, 0, (float)resolution.y, 0.01f, 400);
	camera->SetPosition(glm::vec3(0, 0, 50));
	camera->SetRotation(glm::vec3(0, 0, 0));
	camera->Update();
	GetCameraInput()->SetActive(false);

	glm::vec3 corner = glm::vec3(0, 0, 0);
	float squareSide = 75;
	float triangleSide = 1000;
	float rhombusSide = 60;
	float rectangleSide = 40;

	// compute coordinates of square center
	float cx = corner.x + squareSide / 2;
	float cy = corner.y + squareSide / 2;

	// initialize tx and ty (the translation steps)
	translateX = 0;
	translateY = 0;

	//initialize boolean values and constants
	flyingUp = resolution.y / 2;
	viteza = 10;
	tx1 = resolution.x;
	tx2 = resolution.x;
	tx3 = resolution.x;

	gameState = true;
	printonce = true;
	freeze = true;
	inaltimeDreptunghi = 150;
	lungimeDreptunghi = 150;

	// initialize sx and sy (the scale factors)
	scaleX = 1;
	scaleY = 1;

	// initialize angularStep
	angularStep = 0;

	//initialize score
	score = 0;

	//patrat pasare
	Mesh* square1 = Object2D::CreateSquare("square1", corner, squareSide, glm::vec3(0, 1, 0), true);
	AddMeshToList(square1);

	//desenez rombul parte din pasare
	Mesh* rhombus = Object2D::CreateSquare("rhombus", corner, rhombusSide, glm::vec3(0, 1, 0), true);
	AddMeshToList(rhombus);

	//triunghi pasare
	Mesh* triangle = Object2D::CreateTriangle("triangle", corner, rhombusSide, glm::vec3(0, 1, 0), true);
	AddMeshToList(triangle);

	//dreptunghiul de jos
	Mesh* rectangle1 = Object2D::CreateRectangle("rectangle1", corner, inaltimeDreptunghi, lungimeDreptunghi, glm::vec3(0, 1, 0), true);
	AddMeshToList(rectangle1);

}

void Tema1::FrameStart()
{
	// clears the color buffer (using the previously set color) and depth buffer
	glClearColor(0, 0, 0, 1);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glm::ivec2 resolution = window->GetResolution();
	// sets the screen area where to draw
	glViewport(0, 0, resolution.x, resolution.y);
}

void Tema1::Update(float deltaTimeSeconds)
{
	glm::ivec2 resolution = window->GetResolution();
	score += deltaTimeSeconds;

	modelMatrix = glm::mat3(1);
	viteza -= 100 * deltaTimeSeconds;
	flyingUp += 2 * viteza * deltaTimeSeconds;

	angularStep -= deltaTimeSeconds / 4;
	

	if (flyingUp <= 0 ) {
		gameState = false;
	}

	if (flyingUp >= resolution.y) {
		gameState = false;
	}

	if (gameState == false && printonce == true && freeze == true) {
		printonce = false;
		freeze = false;
		printf("GAME OVER\n");
		printf("score = %f\n", score);
	}

	

	//rombul din pasare 
	modelMatrix = glm::mat3(1);
	modelMatrix *= Transform2D::Translate(resolution.x / 2, flyingUp);
	modelMatrix *= Transform2D::Translate(30, 30);
	modelMatrix *= Transform2D::Rotate(angularStep);
	modelMatrix *= Transform2D::Rotate(3.14/4);
	modelMatrix *= Transform2D::Translate(-30, -30);
	//printf("x: %f\ty: %f\n");
	RenderMesh2D(meshes["rhombus"], shaders["VertexColor"], modelMatrix);

	//patratul din pasare	
	modelMatrix = glm::mat3(1);
	modelMatrix *= Transform2D::Translate(resolution.x / 2 , flyingUp);
	modelMatrix *= Transform2D::Translate(30, 30);
	modelMatrix *= Transform2D::Rotate(angularStep);
	modelMatrix *= Transform2D::Translate(-75 - ((60 *1.41)/2), -37.5);
	RenderMesh2D(meshes["square1"], shaders["VertexColor"], modelMatrix);

	//triunghiul din pasare
	modelMatrix = glm::mat3(1);
	modelMatrix *= Transform2D::Translate(resolution.x / 2 , flyingUp);
	modelMatrix *= Transform2D::Translate(30 , 30);
	modelMatrix *= Transform2D::Rotate(angularStep);
	modelMatrix *= Transform2D::Translate(((60 * 1.41) / 2), 0);
	RenderMesh2D(meshes["triangle"], shaders["VertexColor"], modelMatrix);


	//dreptunghiurile din cadru imperecheate jos - sus
	//fiecare pereche are cate un tx pentru ca sa se deplaseze simultan
	if (freeze == true) {
		//printf("viteza: %f\tflyingUp: %f\n", viteza, flyingUp);
		
		modelMatrix = glm::mat3(1);
		if (tx1 <= -lungimeDreptunghi) tx1 = resolution.x;

		modelMatrix *= Transform2D::Translate(tx1, 0);
		modelMatrix *= Transform2D::Scale(1, 1.5);
		RenderMesh2D(meshes["rectangle1"], shaders["VertexColor"], modelMatrix);

		modelMatrix = glm::mat3(1);
		modelMatrix *= Transform2D::Translate(tx1, 1.5 * inaltimeDreptunghi + resolution.y/3);
		modelMatrix *= Transform2D::Scale(1, (resolution.y - 1.5 * inaltimeDreptunghi + resolution.y / 3)/inaltimeDreptunghi );
		RenderMesh2D(meshes["rectangle1"], shaders["VertexColor"], modelMatrix);
		tx1 -= 250 * deltaTimeSeconds;

		//a doua pereche
		tx2 -= 250 * deltaTimeSeconds ;
		modelMatrix = glm::mat3(1);
		
		modelMatrix *= Transform2D::Translate(tx2 + 2.5 * lungimeDreptunghi, 0);
		modelMatrix *= Transform2D::Scale(scaleX, 2);
		RenderMesh2D(meshes["rectangle1"], shaders["VertexColor"], modelMatrix);

		modelMatrix = glm::mat3(1);
		modelMatrix *= Transform2D::Translate(tx2 + 2.5 * lungimeDreptunghi, 2 * inaltimeDreptunghi + resolution.y / 3);
		modelMatrix *= Transform2D::Scale(1, (resolution.y - 2 * inaltimeDreptunghi + resolution.y / 3) / inaltimeDreptunghi);
		RenderMesh2D(meshes["rectangle1"], shaders["VertexColor"], modelMatrix);
		if (tx2 + 2.5 * lungimeDreptunghi <= -lungimeDreptunghi) tx2 = resolution.x - 2.5 * lungimeDreptunghi;

		//a treia pereche
		tx3 -= 250 * deltaTimeSeconds;
		modelMatrix = glm::mat3(1);

		modelMatrix *= Transform2D::Translate(tx3 + 5 * lungimeDreptunghi, 0);
		modelMatrix *= Transform2D::Scale(scaleX, 3);
		RenderMesh2D(meshes["rectangle1"], shaders["VertexColor"], modelMatrix);

		modelMatrix = glm::mat3(1);
		modelMatrix *= Transform2D::Translate(tx3 + 5 * lungimeDreptunghi, 3 * inaltimeDreptunghi + resolution.y / 3);
		modelMatrix *= Transform2D::Scale(1, (resolution.y - 3 * inaltimeDreptunghi + resolution.y / 3) / inaltimeDreptunghi);
		RenderMesh2D(meshes["rectangle1"], shaders["VertexColor"], modelMatrix);
		if (tx3 + 5 * lungimeDreptunghi <= -lungimeDreptunghi) tx3 = resolution.x - 5 * lungimeDreptunghi;
	}
}

void Tema1::FrameEnd()
{

}

void Tema1::OnInputUpdate(float deltaTime, int mods)
{

}

void Tema1::OnKeyPress(int key, int mods)
{
	if (key == GLFW_KEY_SPACE) {
		viteza = 100;
		angularStep = 0.5;
	}
}

void Tema1::OnKeyRelease(int key, int mods)
{
	// add key release event
}

void Tema1::OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY)
{
	// add mouse move event
}

void Tema1::OnMouseBtnPress(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button press event
}


void Tema1::OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button release event
}

void Tema1::OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY)
{
}

void Tema1::OnWindowResize(int width, int height)
{
}
