#include "Laborator3.h"
#include <vector>
#include <iostream>
#include <Core/Engine.h>
#include "Transform2D.h"
#include "Object2D.h"
using namespace std;

Laborator3::Laborator3()
{
}

Laborator3::~Laborator3()
{
}

void Laborator3::Init()
{
	glm::ivec2 resolution = window->GetResolution();
	auto camera = GetSceneCamera();
	camera->SetOrthographic(0, (float)resolution.x, 0, (float)resolution.y, 0.01f, 400);
	camera->SetPosition(glm::vec3(0, 0, 50));
	camera->SetRotation(glm::vec3(0, 0, 0));
	camera->Update();
	GetCameraInput()->SetActive(false);

	glm::vec3 corner = glm::vec3(0, 0, 0);
	float squareSide = 75;
	float triangleSide = 1000;
	float rhombusSide = 40;
	float rectangleSide = 40;

	// compute coordinates of square center
	float cx = corner.x + squareSide / 2;
	float cy = corner.y + squareSide / 2;

	// initialize tx and ty (the translation steps)
	translateX = 0;
	translateY = 0;
	
	//initialize boolean values and constants
	flyingUp = resolution.y / 2;
	viteza = 10;
	tx1 = 0;
	tx2 = 0;
	tx3 = 0;
	tx4 = 0;
	tx5 = 0;
	tx6 = 0;
	tx7 = 0;
	gameState = true;
	printonce = true;
	freeze = true;
	isBirdFlying = false;
	latimeDreptunghi = 70;

	// initialize sx and sy (the scale factors)
	scaleX = 1;
	scaleY = 1;

	// initialize angularStep
	angularStep = 0;

	//initialize score
	score = 0;
	
	//patrat pasare
	Mesh* square1 = Object2D::CreateSquare("square1", corner, squareSide, glm::vec3(0, 1, 0), true);
	AddMeshToList(square1);

	//desenez rombul parte din pasare
	Mesh* rhombus = Object2D::CreateRhombus("rhombus", corner, rhombusSide, glm::vec3(0, 1, 0), true);
	AddMeshToList(rhombus);

	//triunghi pasare
	Mesh* triangle = Object2D::CreateTriangle("triangle", corner, rhombusSide, glm::vec3(0, 1, 0), true);
	AddMeshToList(triangle);

	//dreptunghiul de jos
	Mesh* rectangle1 = Object2D::CreateRectangle("rectangle1", corner, rectangleSide, rectangleSide,  glm::vec3(0, 1, 0), true);
	AddMeshToList(rectangle1);

	//dreptunghiul de sus
	UpSize = resolution.y - 3.7 * rectangleSide; //calculez de unde sa incep sa desenez de sus
	corner = glm::vec3(0, UpSize, 0);
	Mesh* rectangleUp1 = Object2D::CreateRectangle("rectangleUp1", corner, rectangleSide, rectangleSide, glm::vec3(0, 1, 0), true);
	AddMeshToList(rectangleUp1);
}

void Laborator3::FrameStart()
{
	// clears the color buffer (using the previously set color) and depth buffer
	glClearColor(0, 0, 0, 1);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glm::ivec2 resolution = window->GetResolution();
	// sets the screen area where to draw
	glViewport(0, 0, resolution.x, resolution.y);
}

void Laborator3::Update(float deltaTimeSeconds)
{
	glm::ivec2 resolution = window->GetResolution();
	score += deltaTimeSeconds;

	modelMatrix = glm::mat3(1);
	viteza -= 100 * deltaTimeSeconds;
	flyingUp += viteza * deltaTimeSeconds;
	if (flyingUp <= 0) {
		gameState = false;
	}

	if (flyingUp >= resolution.y){
		gameState = false;
	}

	if (gameState == false && printonce == true && freeze == true) {
		printonce = false;
		freeze = false;
		printf("GAME OVER\n");
		printf("score = %f\n", score);
	}

	//patratul din pasare	
	modelMatrix = glm::mat3(1);
	modelMatrix *= Transform2D::Translate(resolution.x / 2, flyingUp);
	RenderMesh2D(meshes["square1"], shaders["VertexColor"], modelMatrix);


	//rombul din pasare 
	modelMatrix = glm::mat3(1);
	modelMatrix *= Transform2D::Translate(resolution.x / 2 + 75, flyingUp);
	RenderMesh2D(meshes["rhombus"], shaders["VertexColor"], modelMatrix);
	

	//triunghiul din pasare
	modelMatrix = glm::mat3(1);
	modelMatrix *= Transform2D::Translate(resolution.x / 2 + 155, flyingUp + 35);
	RenderMesh2D(meshes["triangle"], shaders["VertexColor"], modelMatrix);


	//dreptunghiurile din cadru imperecheate jos - sus
	//fiecare pereche are cate un tx pentru ca sa se deplaseze simultan
	if (freeze == true) {
		tx1 -= 250 * deltaTimeSeconds;
		modelMatrix = glm::mat3(1);
		if (tx1 <= 0) tx1 = resolution.x;
		else {
			modelMatrix *= Transform2D::Translate(tx1, 0);
			modelMatrix *= Transform2D::Scale(scaleX, 1.5);
		}
		RenderMesh2D(meshes["rectangle1"], shaders["VertexColor"], modelMatrix);

		modelMatrix = glm::mat3(1);
		if (tx1 <= 0) tx1 = resolution.x;
		else modelMatrix *= Transform2D::Translate(tx1, 0);
		RenderMesh2D(meshes["rectangleUp1"], shaders["VertexColor"], modelMatrix);

		//a doua pereche
		tx2 -= 250 * deltaTimeSeconds;
		modelMatrix = glm::mat3(1);
		if (tx2 <= 0) tx2 = resolution.x;
		else {
			modelMatrix *= Transform2D::Translate(tx2 + 4 * latimeDreptunghi, 0);
			modelMatrix *= Transform2D::Scale(scaleX, 2.5);
		}
		RenderMesh2D(meshes["rectangle1"], shaders["VertexColor"], modelMatrix);

		modelMatrix = glm::mat3(1);
		if (tx2 <= 0) tx2 = resolution.x;
		else modelMatrix *= Transform2D::Translate(tx2 + 4 * latimeDreptunghi, 0);
		RenderMesh2D(meshes["rectangleUp1"], shaders["VertexColor"], modelMatrix);

		//a treia pereche
		tx3 -= 250 * deltaTimeSeconds;
		modelMatrix = glm::mat3(1);
		if (tx3 <= 0) tx3 = resolution.x;
		else {
			modelMatrix *= Transform2D::Translate(tx3 + 8 * latimeDreptunghi, 0);
			modelMatrix *= Transform2D::Scale(scaleX, 0.5);
		}
		RenderMesh2D(meshes["rectangle1"], shaders["VertexColor"], modelMatrix);

		modelMatrix = glm::mat3(1);
		if (tx3 <= 0) tx3 = resolution.x;
		else modelMatrix *= Transform2D::Translate(tx3 + 8 * latimeDreptunghi, 0);
		RenderMesh2D(meshes["rectangleUp1"], shaders["VertexColor"], modelMatrix);

		//a patra pereche
		tx4 -= 250 * deltaTimeSeconds;
		modelMatrix = glm::mat3(1);
		if (tx4 <= 0) tx4 = resolution.x;
		else {
			modelMatrix *= Transform2D::Translate(tx4 + 12 * latimeDreptunghi, 0);
			modelMatrix *= Transform2D::Scale(scaleX, 1);
		}
		RenderMesh2D(meshes["rectangle1"], shaders["VertexColor"], modelMatrix);

		modelMatrix = glm::mat3(1);
		if (tx4 <= 0) tx4 = resolution.x;
		else modelMatrix *= Transform2D::Translate(tx4 + 12 * latimeDreptunghi, 0);
		RenderMesh2D(meshes["rectangleUp1"], shaders["VertexColor"], modelMatrix);

		//a cincea pereche
		tx5 -= 250 * deltaTimeSeconds;
		modelMatrix = glm::mat3(1);
		if (tx5 <= 0) tx5 = resolution.x;
		else modelMatrix *= Transform2D::Translate(tx5 + 16 * latimeDreptunghi, 0);
		RenderMesh2D(meshes["rectangle1"], shaders["VertexColor"], modelMatrix);

		modelMatrix = glm::mat3(1);
		if (tx5 <= 0) tx5 = resolution.x;
		else modelMatrix *= Transform2D::Translate(tx5 + 16 * latimeDreptunghi, 0);
		RenderMesh2D(meshes["rectangleUp1"], shaders["VertexColor"], modelMatrix);

		//a sasea pereche
		tx6 -= 250 * deltaTimeSeconds;
		modelMatrix = glm::mat3(1);
		if (tx6 <= 0) tx6 = resolution.x;
		else modelMatrix *= Transform2D::Translate(tx6 + 20 * latimeDreptunghi, 0);
		RenderMesh2D(meshes["rectangle1"], shaders["VertexColor"], modelMatrix);

		modelMatrix = glm::mat3(1);
		if (tx6 <= 0) tx6 = resolution.x;
		else modelMatrix *= Transform2D::Translate(tx6 + 20 * latimeDreptunghi, 0);
		RenderMesh2D(meshes["rectangleUp1"], shaders["VertexColor"], modelMatrix);
	}
}

void Laborator3::FrameEnd()
{

}

void Laborator3::OnInputUpdate(float deltaTime, int mods)
{

}

void Laborator3::OnKeyPress(int key, int mods)
{
	viteza = 100;
	if (key == GLFW_KEY_SPACE) {
		isBirdFlying = true;
	}
	else isBirdFlying = false;
}

void Laborator3::OnKeyRelease(int key, int mods)
{
	// add key release event
}

void Laborator3::OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY)
{
	// add mouse move event
}

void Laborator3::OnMouseBtnPress(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button press event
}


void Laborator3::OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button release event
}

void Laborator3::OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY)
{
}

void Laborator3::OnWindowResize(int width, int height)
{
}
